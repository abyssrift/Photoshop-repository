#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_LoadBtn_clicked();

    void on_FiltersApply_clicked();

    void on_ResetButton_clicked();

    void on_UndoBtn_clicked();

    void on_FuncApply_clicked();

    void on_Savebtn_clicked();

    void on_ExitBtn_clicked();

    void mousePressEvent(QMouseEvent *ev);

    void mouseMoveEvent(QMouseEvent *ev);

    void mouseReleaseEvent(QMouseEvent *ev);

    void handleRadioButtonClicked();

    void handleRadioButtonClicked2();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

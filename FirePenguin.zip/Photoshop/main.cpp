#include "mainwindow.h"
#include <QFileDialog>
#include <QLabel>
#include <QApplication>
#include <QPushButton>





int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("FirePenguin");
    w.showMaximized();
    w.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
    w.show();
    return a.exec();
}



/*
 * Photoshop program by students of cairo universty faculty of computer science for the 2024 competition held by doctor ramly.
 * the photoshop is named firepenguin and has in total, 20 filters and functionalities.
 * the photshop works by combining both utilities of the Image_Class.h library and QImage library.
 * Fire penguin was developed by:
 * Adam Samir Farouk 20230040 Filter 1, Filter 2, Filter 7, Filter 4, Filter 22, Filter 16,
    Nour Alaa Hassan 20230445   Filter 10, Filter 11, Filter 20, Filter 12, Filter 21, Filter 19
    Aya magdi Ali Ahmed 20230084 Filter 5, Filter 8, Filter 9, Filter 15, Filter 17, Filter 18
finished product must be viewed in qt creator so it can launch correctly
*/

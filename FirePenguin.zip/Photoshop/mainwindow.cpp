#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "mainwindow.h"
#include <QFileDialog>
#include <QLabel>
#include <QApplication>
#include <QPushButton>
#include "Image_Class.h"
#include<QMessageBox>
#include <qslider.h>
#include <QSlider>
#include <QInputDialog>
#include <QDebug>
#include <cmath>
#include <QMouseEvent>
#include <QLineEdit>
#include <QDialogButtonBox>
#include <QVBoxLayout>
#include <QRubberBand>
#include <QWidget>
#include <QPainter>
#include <QPixmap>
#include<QCursor>
#include<QRadioButton>
#include <QPushButton>
#include <QImage>
bool ImageLoaded = 0;
bool ImageSaved = 0;
Image image1;
Image backup;
Image undo;
int count;
QPoint origin;
QRubberBand *rubberband;
bool iscropping= 0;

Image filter1( Image processed_image)
{
    unsigned int avg = 0;
    for (int i = 0; i < processed_image.width; ++i)
    {
        for (int j = 0; j < processed_image.height; ++j)
        {
            for (int k = 0; k < 3; ++k)
            {
                avg = processed_image(i,j,k) + avg;
                avg /=3;
            }

            processed_image(i,j,0)=avg;
            processed_image(i,j,1)=avg;
            processed_image(i,j,2)=avg;


        }

    }
    return(processed_image);
}


Image filter2(Image processed_image){
    unsigned int avg = 0;
    for (int i = 0; i < processed_image.width; ++i)
    {
        for (int j = 0; j < processed_image.height; ++j)
        {
            for (int k = 0; k < 3; ++k)
            {
                avg = processed_image(i,j,k) + avg;
                avg/=3;
            }
            if (avg > 80)
            {
                for (int k = 0; k < 3; ++k)
                {
                    processed_image(i,j,k) = 255;
                }
            }
            else if (avg < 80)
            {
                for (int k = 0; k < 3; ++k)
                {
                    processed_image(i,j,k) = 0;
                }
            }
        }
    }
    return(processed_image);
}


Image filter3(Image processed_image){
    for(int i=0; i<processed_image.width; i++){

        for(int j=0; j<processed_image.height; j++){
            unsigned int avg[3];

            avg[0] = 255 - processed_image(i, j, 0);
            avg[1] = 255 - processed_image(i, j, 1);
            avg[2] = 255 - processed_image(i, j, 2);

            for(int k=0; k<3; k++){
                processed_image(i, j, k ) = avg[k];

            }

        }
    }
    return(processed_image);

}


//add frames to images
Image filter4simple(Image processed_image, int result){
    Image image = processed_image;
   int colo = result;
        unsigned int frameSize = image.width/60;

        for (unsigned int i = 5; i < image.width-5; i++) {
            for (unsigned int j = 5; j < image.height-5; j++) {

                if (i < frameSize || j < frameSize || i >= image.width - frameSize || j >= image.height - frameSize) {
                    if(colo == 1){
                        for (int k = 0; k < 3; k++) {
                            image(i, j, k) = 255;
                        }
                    }
                    else if(colo == 2){
                        image(i, j, 0) = 255;  image(i, j, 1) = 0;  image(i, j, 2) = 0;
                    }
                    else if(colo == 3){
                        image(i, j, 0) = 0;  image(i, j, 1) = 255;  image(i, j, 2) = 0;
                    }
                    else if(colo == 4){
                        image(i, j, 0) = 0;  image(i, j, 1) = 0;  image(i, j, 2) = 255;
                    }
                    else{
                    }
                }
            }
        }
        return(image);
    }
Image Filter4Fancy(Image image, int value){
    int colo = value;
    unsigned int frameSize = image.height/90;

    for (unsigned int i = 5; i < image.width-5; i++) {
        for (unsigned int j = 5; j < image.height-5; j++) {

            if (i < frameSize || j < frameSize || i >= image.width - frameSize || j >= image.height - frameSize) {
                if(colo == 1){
                    for (int k = 0; k < 3; k++) {
                        image(i, j, k) = 255;
                    }
                }
                else if(colo == 2){
                    image(i, j, 0) = 255;  image(i, j, 1) = 0;  image(i, j, 2) = 0;
                }
                else if(colo == 3){
                    image(i, j, 0) = 0;  image(i, j, 1) = 255;  image(i, j, 2) = 0;
                }
                else if(colo == 4){
                    image(i, j, 0) = 0;  image(i, j, 1) = 0;  image(i, j, 2) = 255;
                }
            }
        }
    }

    unsigned int frameSize2 = image.height/60;

    for (unsigned int i = 10; i < image.width-10; i++) {
        for (unsigned int j = 10; j < image.height-10; j++) {

            if (i < frameSize2 || j < frameSize2 || i >= image.width - frameSize2 || j >= image.height - frameSize2) {
                if(colo == 1){
                    for (int k = 0; k < 3; k++) {
                        image(i, j, k) = 255;
                    }
                }
                else if(colo == 2){
                    image(i, j, 0) = 255;  image(i, j, 1) = 0;  image(i, j, 2) = 0;
                }
                else if(colo == 3){
                    image(i, j, 0) = 0;  image(i, j, 1) = 255;  image(i, j, 2) = 0;
                }
                else if(colo == 4){
                    image(i, j, 0) = 0;  image(i, j, 1) = 0;  image(i, j, 2) = 255;
                }
            }

            if (i < frameSize2 * 2 && j < frameSize2 * 2 || i >= image.width-1-frameSize2 * 2 && j >= image.height-1-frameSize2 * 2 ||
                i < frameSize2 * 2 && j >= image.height-1-frameSize2 * 2 || i >= image.width-1-frameSize2 * 2 && j < frameSize2 * 2){
                if(colo == 1){
                    for (int k = 0; k < 3; k++) {
                        image(i, j, k) = 255;
                    }
                }
                else if(colo == 2){
                    image(i, j, 0) = 255;  image(i, j, 1) = 0;  image(i, j, 2) = 0;
                }
                else if(colo == 3){
                    image(i, j, 0) = 0;  image(i, j, 1) = 255;  image(i, j, 2) = 0;
                }
                else if(colo == 4){
                    image(i, j, 0) = 0;  image(i, j, 1) = 0;  image(i, j, 2) = 255;
                }
            }

            if ((i < frameSize2 * 4 && i > frameSize2 * 3 && j < frameSize2 * 4 && j > frameSize2 * 3) ||
                (i >= image.width - 1 - frameSize2 * 4 && i < image.width - 1 - frameSize2 * 3 &&
                 j >= image.height - 1 - frameSize2 * 4 && j < image.height - 1 - frameSize2 * 3) ||
                (i < frameSize2 * 4 && i > frameSize2 * 3 && j >= image.height - 1 - frameSize2 * 4 && j < image.height - 1 - frameSize2 * 3) ||
                (i >= image.width - 1 - frameSize2 * 4 && i < image.width - 1 - frameSize2 * 3 && j < frameSize2 * 4 && j > frameSize2 * 3 )) {

                if(colo == 1){
                    for (int k = 0; k < 3; k++) {
                        image(i, j, k) = 255;
                    }
                }
                else if(colo == 2){
                    image(i, j, 0) = 255;  image(i, j, 1) = 0;  image(i, j, 2) = 0;
                }
                else if(colo == 3){
                    image(i, j, 0) = 0;  image(i, j, 1) = 255;  image(i, j, 2) = 0;
                }
                else if(colo == 4){
                    image(i, j, 0) = 0;  image(i, j, 1) = 0;  image(i, j, 2) = 255;
                }
            }
            if(j < frameSize2 * 4  && j > frameSize2 * 4 - 5 || i < frameSize2 * 4 && i > frameSize2 * 4 - 5 ||
                j > image.height - frameSize2 * 4 - 5 && j < image.height - frameSize2 * 4 || i > image.width - frameSize2 * 4 - 5 && i < image.width - frameSize2 * 4
                ){
                if(i < frameSize2 * 4 && j < frameSize2 * 4){
                    if(colo == 1){
                        for (int k = 0; k < 3; k++) {
                            image(i, j, k) = 255;
                        }
                    }
                    else if(colo == 2){
                        image(i, j, 0) = 255;  image(i, j, 1) = 0;  image(i, j, 2) = 0;
                    }
                    else if(colo == 3){
                        image(i, j, 0) = 0;  image(i, j, 1) = 255;  image(i, j, 2) = 0;
                    }
                    else if(colo == 4){
                        image(i, j, 0) = 0;  image(i, j, 1) = 0;  image(i, j, 2) = 255;
                    }
                }
                else if(i < frameSize2 * 4 && j > image.height - frameSize2 * 4 - 5){
                    if(colo == 1){
                        for (int k = 0; k < 3; k++) {
                            image(i, j, k) = 255;
                        }
                    }
                    else if(colo == 2){
                        image(i, j, 0) = 255;  image(i, j, 1) = 0;  image(i, j, 2) = 0;
                    }
                    else if(colo == 3){
                        image(i, j, 0) = 0;  image(i, j, 1) = 255;  image(i, j, 2) = 0;
                    }
                    else if(colo == 4){
                        image(i, j, 0) = 0;  image(i, j, 1) = 0;  image(i, j, 2) = 255;
                    }
                }
                else if (i > image.width - frameSize2 * 4 - 5 && j < frameSize2 * 4){
                    if(colo == 1){
                        for (int k = 0; k < 3; k++) {
                            image(i, j, k) = 255;
                        }
                    }
                    else if(colo == 2){
                        image(i, j, 0) = 255;  image(i, j, 1) = 0;  image(i, j, 2) = 0;
                    }
                    else if(colo == 3){
                        image(i, j, 0) = 0;  image(i, j, 1) = 255;  image(i, j, 2) = 0;
                    }
                    else if(colo == 4){
                        image(i, j, 0) = 0;  image(i, j, 1) = 0;  image(i, j, 2) = 255;
                    }
                }
                else if(i > image.width - frameSize2 * 4 - 5 && j > image.height - frameSize2 * 4 - 5){
                    if(colo == 1){
                        for (int k = 0; k < 3; k++) {
                            image(i, j, k) = 255;
                        }
                    }
                    else if(colo == 2){
                        image(i, j, 0) = 255;  image(i, j, 1) = 0;  image(i, j, 2) = 0;
                    }
                    else if(colo == 3){
                        image(i, j, 0) = 0;  image(i, j, 1) = 255;  image(i, j, 2) = 0;
                    }
                    else if(colo == 4){
                        image(i, j, 0) = 0;  image(i, j, 1) = 0;  image(i, j, 2) = 255;
                    }
                }
            }

        }
    }

    return(image);
}
int kernelSize = 3;
Image filter5blur(Image processed_image,int kernelSize){
    int width = processed_image.width;
    int height = processed_image.height;


    for (int x = 0; x < width; ++x) {
        for (int y = 0; y < height; ++y) {
            for (int k = 0; k < 3; ++k) {

                int sum = 0;
                int count = 0;

                for (int dx = -kernelSize ; dx <= kernelSize ; ++dx) {
                    for (int dy = -kernelSize ; dy <= kernelSize ; ++dy) {
                        // Check bounds
                        if ((x + dx >= 0 && x + dx < width) && (y + dy >= 0 && y + dy < height)) {
                            sum += processed_image.getPixel(x + dx, y + dy, k);
                            count++;
                        }
                    }
                }

                unsigned int avg = sum / count;
                processed_image.setPixel(x, y, k, avg);
            }
        }
    }
    return(processed_image);
}

//adds sunshine to the image
Image filter6sunshine(Image proccessed_image){
    for (int i = 0; i < proccessed_image.width; i++)
    {
        for (int j = 0; j < proccessed_image.height; j++)
        {
            proccessed_image(i,j,0)=proccessed_image(i,j,0);
            proccessed_image(i,j,1)=proccessed_image(i,j,1);
            proccessed_image(i,j,2)=fmax(0,proccessed_image(i,j,2)-50);


        }

    }
    return(proccessed_image);
}
//oilpainting filter
Image filter7oilpaint(Image processed_image)
{
    int width = processed_image.width;
    int height = processed_image.height;
    for (int x = 0; x < width; ++x) {
        for (int y = 0; y < height; ++y) {
            for (int k = 0; k < 2; k++)
            {
                processed_image(x,y,k)/=30;
                processed_image(x,y,k)*=30;
            }

        }
    }
    return(processed_image);
}
//television effect filter
Image filter8television(Image processed_image)
{
    srand(time(0));
    Image newImage(processed_image.width,processed_image.height);
    for (int i = 0; i < processed_image.width; i++)
    {
        for (int j = 0; j < processed_image.height; j++)
        {
            for (int k = 0; k < 3; k++)
            {
                int randomvalue = rand()%100;
                int coinflip = rand()%2;
                if(coinflip == 1){
                    newImage(i,j,k) = fmin(255,processed_image(i,j,k) + randomvalue);
                }
            }
        }
    }
    return(newImage);
}
//purple filter
Image filter9purple(Image processed_image){
    for (int i = 0; i < processed_image.width; i++)
    {
        for (int j = 0; j < processed_image.height; j++)
        {
            processed_image(i,j,0)=processed_image(i,j,0);
            processed_image(i,j,1)=fmax(0,processed_image(i,j,1)-50);
            processed_image(i,j,2)=processed_image(i,j,2);


        }

    }
    return(processed_image);
}
//infrared filter
Image filter10infrared(Image processed_image){
    for (int i = 0; i < processed_image.width; i++)
    {
        for (int j = 0; j < processed_image.height; j++)
        {
            processed_image(i,j,0)=255;
            processed_image(i,j,1)=255-processed_image(i,j,1);
            processed_image(i,j,2)=255-processed_image(i,j,2);


        }

    }
    return(processed_image);
}

Image slightblur(Image processed_image){
    int width = processed_image.width;
    int height = processed_image.height;

    int kernelSize = 3;

    for (int x = 0; x < width; ++x) {
        for (int y = 0; y < height; ++y) {
            for (int k = 0; k < 3; ++k) {

                int sum = 0;
                int count = 0;

                for (int dx = -kernelSize ; dx <= kernelSize ; ++dx) {
                    for (int dy = -kernelSize ; dy <= kernelSize ; ++dy) {
                        // Check bounds
                        if ((x + dx >= 0 && x + dx < width) && (y + dy >= 0 && y + dy < height)) {
                            sum += processed_image.getPixel(x + dx, y + dy, k);
                            count++;
                        }
                    }
                }

                unsigned int avg = sum / count;
                processed_image.setPixel(x, y, k, avg);
            }
        }
    }
    return(processed_image);
}

//adds random white stars at random highlight points and slightly blurs the image
Image filter11disney(Image processed_image){
    srand(time(0));
    for (int x = 0; x < processed_image.width; x++)
    {
        for (int y = 0; y < processed_image.height; y++)
        {
            if(processed_image(x,y,0)> 220 && processed_image(x,y,1)>220 && processed_image(x,y,2)>220 && y < processed_image.height-100 && x < processed_image.width - 100 && x > 100 && y > 100)
            {
                srand(time(0));
                int randomint = rand()%30;
                //making sure that the size of stars is different
                for (int h = 0; h < 30+randomint ; h++)
                {
                    for (int k = 0; k < 3; ++k)
                    {
                        processed_image(x+h,y,k) = 180+randomint*2;
                        processed_image(x-h,y,k) = 180+randomint*2;
                        processed_image(x,y-h,k) = 180+randomint*2;
                        processed_image(x,y+h,k) = 180+randomint*2;

                        //making sure highlights arent spammed with stars

                    }
                }
                srand(time(0));
                int distance = rand()%40;
                y=(fmin(y+100+randomint + distance,processed_image.height));
                x=(fmin(x+100+randomint + distance,processed_image.width));
            }
        }
    }
    return(processed_image);
}

//contrast filter to enhance images
Image filter12contrast(Image processed_image)
{
    int intensity;
    for (int i = 0; i < processed_image.width; i++)
    {
        for (int j = 0; j < processed_image.height; j++)
        {
            intensity = processed_image(i,j,0) + processed_image(i,j,1) + processed_image(i,j,2);
            intensity /=3;
            //contrast where if intensity is higher than a threshold, light things get lighter
            if (intensity > 160 )
            {
                for (int k = 0; k < 3; k++)
                {
                    processed_image(i,j,k) = fmin(255,processed_image(i,j,k) + 40);
                }

            }
            //contrast where if intensity is lower than a threshold, dark things get darker
            else if(intensity < 100)
            {
                for (size_t k = 0; k < 3; k++)
                {
                    processed_image(i,j,k) = fmax(0,processed_image(i,j,k) - 40);
                }

            }

        }
    }





    return(processed_image);
}

//merge two images
Image functionality1 (Image processed_image,Image processed_image2)
{
    int min_width = fmin(processed_image.width,processed_image2.width);
    int min_height = fmin(processed_image.height,processed_image2.height);
    Image mergeimage(min_width,min_height);
    int avg = 0;
    for (int i = 0; i < mergeimage.width-1; ++i)
    {
        for (int j = 0; j < mergeimage.height; ++j)
        {
            for (int k = 0; k < 3; ++k)
            {
                avg = processed_image(i,j,k) + processed_image2(i,j,k);
                mergeimage(i,j,k) = avg/2;
            }

        }
    }
    return(mergeimage);
}
//flip image
Image functionality2(Image processed_image){
    Image originalImage;
    originalImage = processed_image;
    int x = originalImage.width ;


    // Create a new image to store the flipped version
    Image flippedImage(originalImage.width, originalImage.height);

    // Flip the image horizontally
    for (int i = 0; i < originalImage.width; ++i) {
        for (int j = 0; j < originalImage.height; ++j) {
            for (int k= 0; k < 3; ++k) { // Assuming 3 channels (RGB)
                // Copy pixels from the original image to the flipped image in reverse order along the vertical axis
                flippedImage( x -1 - i, j, k) = originalImage(i, j, k);
            }
        }
    }
    return(flippedImage);
}

//rotate images
Image functionality3rotate1(Image photo,int totalRotation){
    // Initialize total rotation angle

    while (true) {
        // Perform rotation based on the total rotation angle
        Image rotatedImage(photo.height, photo.width);
        for (int i = 0; i < photo.width; ++i) {
            for (int j = 0; j < photo.height; ++j) {
                for (int k = 0; k < photo.channels; ++k) {
                    // Rotate the pixel by 90 degrees clockwise
                    rotatedImage(photo.height - 1 - j, i, k) = photo(i, j, k);
                }
            }
        }
    return (rotatedImage);
}
}
Image functionality3rotate2(Image photo){

        Image route(photo.height, photo.width);


        for(int i=0; i<photo.width; i++){
            for(int j=0; j<photo.height; j++){

                for(int k=0; k<photo.channels; k++){
                    route(photo.height-1-j, i, k) = photo(i, j, k);
                }

            }
        }
        Image route2(route.height, route.width);
        for(int i=0; i<route.width; i++){
            for(int j=0; j<route.height; j++){

                for(int k=0; k<route.channels; k++){
                    route2(route.height-1-j, i, k) = route(i, j, k);
                }
            }
        }

        return(route2);
    }

Image functionality3rotate3(Image photo){

        Image route(photo.height, photo.width);

        for(int i=0; i<photo.width; i++){
            for(int j=0; j<photo.height; j++){

                for(int k=0; k<photo.channels; k++){
                    route(j, i, k)= photo(i, j, k);
                }
            }
        }

        return(route);
}

float value;
//darken and lighten images
Image functionalityldarken(Image processed_image){
        value = (value/100)*10;
        for(int i=0; i <processed_image.width;i++){
            for(int j=0;j<processed_image.height;j++){
                for(int k=0;k<3;++k)
                {
                    processed_image(i,j,k) = processed_image(i,j,k)/(value);
                }
            }
        }
        return processed_image;
    }
Image functionalitylighten(Image processed_image){
    {
        value = (value/101);
        for(int i=0; i <processed_image.width;i++){
            for(int j=0;j<processed_image.height;j++){
                for(int k=0;k<3;++k)
                {
                    processed_image(i,j,k) = processed_image(i,j,k)+((255-processed_image(i,j,k))*value);
                }
            }
        }
    }
    return(processed_image);
}
float PI = 3.14159265358979323846;
Image functionality6skew(Image processed_image,float skew_Degree){
    Image originalImage;
    originalImage = processed_image;
    // Calculate radians from degrees for trigonometric functions
    float skew_Radians = (skew_Degree * PI / 180.0);

    // Calculate the dimensions of the skewed image
    int skewed_Width = originalImage.width + abs((int)(originalImage.height * tan(skew_Radians)));
    int skewed_Height = originalImage.height;

    // Create a new image to store the skewed version
    Image skewedImage(skewed_Width, skewed_Height);

    // Apply skewing to each pixel
    for (int i = 0; i < skewed_Width; ++i) {
        for (int j = 0; j < skewed_Height; ++j) {
            // Calculate the corresponding coordinates in the original image
            int originalX = i - j * tan(skew_Radians);
            int originalY = j;

            // Check if the coordinates are within the bounds of the original image
            if (originalX >= 0 && originalX < originalImage.width && originalY >= 0 && originalY < originalImage.height) {
                // Copy pixel values from the original image to the skewed image
                for (int k = 0; k < originalImage.channels; ++k) {
                    skewedImage(i, j, k) = originalImage(originalX, originalY, k);
                }
            }
        }
    }
    return(skewedImage);
}

Image Functionality8resize(Image processed_image, int new_Width, int new_Height){
    Image originalImage;
    originalImage = processed_image;
    // Calculate the scaling factors
    float scaleX = (float)originalImage.width / new_Width;
    float scaleY = (float)originalImage.height / new_Height;

    // Create a new image to store the resized version
    Image resizedImage(new_Width, new_Height);

    // Perform nearest-neighbor interpolation
    for (int i = 0; i < new_Height; ++i) {
        for (int j = 0; j < new_Width; ++j) {
            // Calculate the corresponding position in the original image
            int srcX = (int)(j * scaleX);
            int srcY = (int)(i * scaleY);

            // Copy the pixel value from the original image to the resized image
            for (int k = 0; k < 3; ++k) {
                resizedImage(j, i, k) = originalImage(srcX, srcY, k);
            }
        }
    }
    return (resizedImage);
}


// Function to convert the image to gray and white
void convertToGrayAndWhite(Image& img) {
    int avg;
    for (int i = 0; i < img.width; ++i) {
        for (int j = 0; j < img.height; ++j) {
            avg = 0;
            // Calculate average pixel value
            for (int k = 0; k < 3; ++k) {
                avg += img(i, j, k);
            }
            avg /= 3;

            // Apply threshold to convert to gray and white
            if (avg > 127) {
                // Set pixel to white (255) for each channel
                for (int k = 0; k < 3; ++k) {
                    img(i, j, k) = 255;
                }
            }
            else {
                // Set pixel to gray (128) for each channel
                for (int k = 0; k < 3; ++k) {
                    img(i, j, k) = 128;
                }
            }
        }
    }
}

// Function to detect edges in the picture using Sobel edge detection
Image detectEdges(const Image& img) {
    int width = img.width;
    int height = img.height;

    // Create a copy of the input image for processing
    Image processedImg = img;

    Image edges(width, height); // Create a new single-channel image for edges

    // Sobel operators for edge detection
    int sobelX[3][3] = { {-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1} };
    int sobelY[3][3] = { {1, 2, 1}, {0, 0, 0}, {-1, -2, -1} };

    // Apply Sobel operator to each pixel in the image
    for (int x = 1; x < width - 1; ++x) {
        for (int y = 1; y < height - 1; ++y) {
            int gradientX = 0;
            int gradientY = 0;

            // Compute gradients in x and y directions
            for (int i = -1; i <= 1; ++i) {
                for (int j = -1; j <= 1; ++j) {
                    gradientX += processedImg(x + i, y + j, 0) * sobelX[i + 1][j + 1];
                    gradientY += processedImg(x + i, y + j, 0) * sobelY[i + 1][j + 1];
                }
            }

            // Compute gradient magnitude
            int magnitude = sqrt(gradientX * gradientX + gradientY * gradientY);

            // Apply a threshold to detect edges
            if (magnitude > 100) {
                edges(x, y, 0) = 50;
                edges(x, y, 1) = 50;
                edges(x, y, 2) = 50;// Set edge pixel to gray
            }
            else {
                edges(x, y, 0) = 255;
                edges(x, y, 1) = 255;
                edges(x, y, 2) = 255;// Set non-edge pixel to white
            }
        }
    }
    return(edges);
}

Image functionality6edges(Image processed_image){
    convertToGrayAndWhite(processed_image);
    processed_image = detectEdges(processed_image);
    return(processed_image);
}








MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    showMaximized();
    ui->setupUi(this);

}




MainWindow::~MainWindow()
{
    delete ui;
}



Image PlaceHolder;

void MainWindow::handleRadioButtonClicked() {
    QRadioButton* button = qobject_cast<QRadioButton*>(sender()); // Get the sender button
    if (button) {
        int value = button->property("value").toInt(); // Retrieve the value property
        PlaceHolder = filter4simple(image1,value);
    }
}

void MainWindow::handleRadioButtonClicked2() {
    QRadioButton* button = qobject_cast<QRadioButton*>(sender()); // Get the sender button
    if (button) {
        int value = button->property("value").toInt(); // Retrieve the value property
        PlaceHolder = Filter4Fancy(image1, value);
    }
}

void MainWindow::on_LoadBtn_clicked()
{
    // Open a file dialog for image selection
    QString imagePath = QFileDialog::getOpenFileName(nullptr, "Select Image", "", "Images (*.png *.jpg *.bmp)");

    // Check if the user canceled the dialog or no file was selected
    if (imagePath.isEmpty()) {
        qDebug() << "No image selected";
        return;
    }
    image1.loadNewImage(imagePath.toStdString());
    // Load the selected image
    QPixmap image2(imagePath);

    // Check if the image was loaded successfully
    if (image2.isNull()) {
        qDebug() << "Failed to load image";
        return;
    }

    // Create a QLabel to display the image
    ui->Main_Image->setScaledContents(true);
    ui->Main_Image->setPixmap(image2);
    ui->sec_Image->setScaledContents(true);
    backup = image1;
    ImageLoaded = true;
}

void MainWindow::on_FiltersApply_clicked()
{
    QApplication::setOverrideCursor(Qt::BusyCursor);
    QImage backupImage(backup.width, backup.height, QImage::Format_RGB888);
    for(int i = 0; i < backup.width ; i++){
        for(int j = 0; j < backup.height ; j++){
            int red = backup(i,j,0);
            int green = backup(i,j,1);
            int blue = backup(i,j,2);
            backupImage.setPixel(i,j,qRgb(red,green,blue));
        }
    }
    QPixmap pixmapbackup = QPixmap::fromImage(backupImage);
    ui->sec_Image->setPixmap(pixmapbackup);



    int Choice = ui->ComboFilters->currentIndex();
    if(Choice == 0 && ImageLoaded == 1)
    {
    //gray scale itself
    //takes copy of image before filter so i can undo it
    undo = image1;
    image1 = filter1(image1);
    QImage GrayImage(image1.width, image1.height, QImage::Format_RGB888);
    for(int i = 0; i < image1.width ; i++){
        for(int j = 0; j < image1.height ; j++){
            int red = image1(i,j,0);
            int green = image1(i,j,1);
            int blue = image1(i,j,2);
            GrayImage.setPixel(i,j,qRgb(red,green,blue));
        }
    }
    //backup button
    QPixmap pixmapGray = QPixmap::fromImage(GrayImage);
    ui->Main_Image->setPixmap(pixmapGray);
    }
    //filter 2
    else if(Choice == 1 && ImageLoaded ==1){
        //takes copy of image before filter so i can undo it
        undo = image1;
        image1 = filter2(image1);
        QImage BlackImage(image1.width, image1.height, QImage::Format_RGB888);
        for(int i = 0; i < image1.width ; i++){
            for(int j = 0; j < image1.height ; j++){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                BlackImage.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapBlack = QPixmap::fromImage(BlackImage);
        ui->Main_Image->setPixmap(pixmapBlack);

    }
    else if(Choice == 2 && ImageLoaded == 1){
        //takes copy of image before filter so i can undo it
        undo = image1;
        image1 = filter3(image1);;
        QImage InvertedImage(image1.width,image1.height,QImage::Format_RGB888);
        for(int i = 0; i < image1.width ; i++){
            for(int j = 0; j < image1.height ; j++){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                InvertedImage.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapInverted = QPixmap::fromImage(InvertedImage);
        ui->Main_Image->setPixmap(pixmapInverted);
    }

    else if(Choice == 3 && ImageLoaded == 1){
    //takes copy of image before filter so i can undo it
        undo = image1;
    QDialog Color_Selection;
    Color_Selection.setWindowTitle("Color Selection");
    Color_Selection.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
    Color_Selection.setFixedWidth(500);
    Color_Selection.setStyleSheet("QDialog { background-color: #55557F; color: white;}"
    "QPushButton {background-color:#5550B2; color: white;}");
    QVBoxLayout *layout = new QVBoxLayout;
    Color_Selection.setLayout(layout);

    QRadioButton *whiteButton = new QRadioButton("White");
    whiteButton->setObjectName("whiteButton");
    layout->addWidget(whiteButton);

    QRadioButton *redButton = new QRadioButton("Red");
    redButton->setObjectName("redButton");
    layout->addWidget(redButton);

    QRadioButton *greenButton = new QRadioButton("Green");
    greenButton->setObjectName("greenButon");
    layout->addWidget(greenButton);

    QRadioButton *blueButton = new QRadioButton("Blue");
    blueButton->setObjectName("blueButton");
    layout->addWidget(blueButton);


    whiteButton->setChecked(true);

    whiteButton->setProperty("value", 1);
    redButton->setProperty("value", 2);
    greenButton->setProperty("value", 3);
    blueButton->setProperty("value", 4);


    // Connect the buttonClicked signal of each radio button to a custom slot
    QObject::connect(whiteButton, &QRadioButton::clicked, this, &MainWindow::handleRadioButtonClicked);
    QObject::connect(redButton, &QRadioButton::clicked, this, &MainWindow::handleRadioButtonClicked);
    QObject::connect(greenButton, &QRadioButton::clicked, this, &MainWindow::handleRadioButtonClicked);
    QObject::connect(blueButton, &QRadioButton::clicked, this, &MainWindow::handleRadioButtonClicked);



    QDialogButtonBox *ButtonBox1 = new QDialogButtonBox;
    ButtonBox1 = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    layout->addWidget(ButtonBox1);
    connect(ButtonBox1, &QDialogButtonBox::accepted, &Color_Selection, &QDialog::accept);
    connect(ButtonBox1, &QDialogButtonBox::rejected, &Color_Selection, &QDialog::reject);

    Color_Selection.exec();

    image1 = PlaceHolder;
    QImage SimpleFramed(image1.width,image1.height,QImage::Format_RGB888);
    for (int i = 0; i < image1.width; ++i) {
        for(int j = 0; j < image1.height; ++j){
            int red = image1(i,j,0);
            int green = image1(i,j,1);
            int blue = image1(i,j,2);
            SimpleFramed.setPixel(i,j,qRgb(red,green,blue));
        }
    }
    QPixmap pixmapSimpleFramed = QPixmap::fromImage(SimpleFramed);
    ui->Main_Image->setPixmap(pixmapSimpleFramed);
    }
    else if(Choice == 4 && ImageLoaded == 1){
        //takes copy of image before filter so i can undo it


        QDialog Color_Selection;
        Color_Selection.setWindowTitle("Color_Selection");
        Color_Selection.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
        Color_Selection.setFixedWidth(500);
        Color_Selection.setStyleSheet("QDialog { background-color: #55557F; color: white;}"
                                      "QPushButton {background-color:#5550B2; color: white;}");
        QVBoxLayout *layout = new QVBoxLayout;
        Color_Selection.setLayout(layout);

        QRadioButton *whiteButton = new QRadioButton("White");
        whiteButton->setObjectName("whiteButton");
        layout->addWidget(whiteButton);

        QRadioButton *redButton = new QRadioButton("Red");
        redButton->setObjectName("redButton");
        layout->addWidget(redButton);

        QRadioButton *greenButton = new QRadioButton("Green");
        greenButton->setObjectName("greenButon");
        layout->addWidget(greenButton);

        QRadioButton *blueButton = new QRadioButton("Blue");
        blueButton->setObjectName("blueButton");
        layout->addWidget(blueButton);


        whiteButton->setChecked(true);
        whiteButton->setProperty("value", 1);
        redButton->setProperty("value", 2);
        greenButton->setProperty("value", 3);
        blueButton->setProperty("value", 4);


        // Connect the buttonClicked signal of each radio button to a custom slot
        QObject::connect(whiteButton, &QRadioButton::clicked, this, &MainWindow::handleRadioButtonClicked2);
        QObject::connect(redButton, &QRadioButton::clicked, this, &MainWindow::handleRadioButtonClicked2);
        QObject::connect(greenButton, &QRadioButton::clicked, this, &MainWindow::handleRadioButtonClicked2);
        QObject::connect(blueButton, &QRadioButton::clicked, this, &MainWindow::handleRadioButtonClicked2);



        QDialogButtonBox *ButtonBox1 = new QDialogButtonBox;
        ButtonBox1 = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
        layout->addWidget(ButtonBox1);
        connect(ButtonBox1, &QDialogButtonBox::accepted, &Color_Selection, &QDialog::accept);
        connect(ButtonBox1, &QDialogButtonBox::rejected, &Color_Selection, &QDialog::reject);

        Color_Selection.exec();

        undo = image1;
        image1 = PlaceHolder;
        QImage FancyFramed(image1.width,image1.height,QImage::Format_RGB888);
        for (int i = 0; i < image1.width; ++i) {
            for(int j = 0; j < image1.height; ++j){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                FancyFramed.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapFancyFramed = QPixmap::fromImage(FancyFramed);
        ui->Main_Image->setPixmap(pixmapFancyFramed);
    }

    else if (Choice == 5 && ImageLoaded == 1) {
        QMessageBox SliderValue;
        SliderValue.setWindowTitle("Degree of Blur");
        SliderValue.setIcon(QMessageBox::Information);
        SliderValue.setStyleSheet("QLabel { color : white; }");
        SliderValue.setStyleSheet("QMessageBox { background-color: #55557F; }"
        "QPushButton {background-color:#5550B2; color: white;}");
        SliderValue.setText("Please insert your degree of blur");
        SliderValue.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
        QSlider *kernelSizeslid = new QSlider(Qt::Horizontal);
        kernelSizeslid->setRange(0, 8); // Set the range of the slider
        kernelSizeslid->setValue(4); // Set initial value
        kernelSizeslid->setMinimumWidth(150);
        kernelSizeslid->setStyleSheet("QSlider { background-color: #5550B2; color: white;}");

        SliderValue.layout()->addWidget(kernelSizeslid);

        int kernelSize = kernelSizeslid->value();
        QObject::connect(kernelSizeslid, &QSlider::valueChanged, [&kernelSize](int value){
            kernelSize = value; // Update the kernel size
        });

        // Show the message box
        SliderValue.exec();

        // Now you can use the updated kernelSize variable here
        qDebug() << "Selected kernel size: " << kernelSize;

        // Use the updated kernelSize variable to apply the filter
        undo = image1;
        if(kernelSize > 7){QMessageBox::critical(this,"Warning!","Warning! Selecting a Blur Degree Above 7 Takes Intensive Processing! Please Wait while image is processing");}
        image1 = filter5blur(image1, kernelSize);

        // Convert the processed image to QPixmap and display it
        QImage blurredImage(image1.width, image1.height, QImage::Format_RGB888);
        for (int i = 0; i < image1.width; ++i) {
            for (int j = 0; j < image1.height; ++j) {
                int red = image1(i, j, 0);
                int green = image1(i, j, 1);
                int blue = image1(i, j, 2);
                blurredImage.setPixel(i, j, qRgb(red, green, blue));
            }
        }
        ui->Main_Image->setPixmap(QPixmap::fromImage(blurredImage));
    }
    else if(Choice == 6 && ImageLoaded == 1){        //takes copy of image before filter so i can undo it
        undo = image1;
        image1 = filter6sunshine(image1);;
        QImage sunshine(image1.width,image1.height,QImage::Format_RGB888);
        for (int i = 0; i < image1.width; ++i) {
            for(int j = 0; j < image1.height; ++j){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                sunshine.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapsunshine = QPixmap::fromImage(sunshine);
        ui->Main_Image->setPixmap(pixmapsunshine);
    }
    else if(Choice == 7 && ImageLoaded == 1){
        undo = image1;
        image1 = filter7oilpaint(image1);;
        QImage oilpaint(image1.width,image1.height,QImage::Format_RGB888);
        for (int i = 0; i < image1.width; ++i) {
            for(int j = 0; j < image1.height; ++j){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                oilpaint.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapoilpaint = QPixmap::fromImage(oilpaint);
        ui->Main_Image->setPixmap(pixmapoilpaint);
    }
    else if(Choice == 8 && ImageLoaded == 1){
        undo = image1;
        image1 = filter8television(image1);;
        QImage television(image1.width,image1.height,QImage::Format_RGB888);
        for (int i = 0; i < image1.width; ++i) {
            for(int j = 0; j < image1.height; ++j){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                television.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmaptelevision = QPixmap::fromImage(television);
        ui->Main_Image->setPixmap(pixmaptelevision);
    }
    else if(Choice == 9 && ImageLoaded == 1){
        undo = image1;
        image1 = filter9purple(image1);;
        QImage purple(image1.width,image1.height,QImage::Format_RGB888);
        for (int i = 0; i < image1.width; ++i)
        {
            for(int j = 0; j < image1.height; ++j)
            {
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                purple.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmappurple = QPixmap::fromImage(purple);
        ui->Main_Image->setPixmap(pixmappurple);
    }
        else if(Choice == 10 && ImageLoaded == 1){
            undo = image1;
            image1 = filter10infrared(image1);;
            QImage infrared(image1.width,image1.height,QImage::Format_RGB888);
            for (int i = 0; i < image1.width; ++i) {
                for(int j = 0; j < image1.height; ++j){
                    int red = image1(i,j,0);
                    int green = image1(i,j,1);
                    int blue = image1(i,j,2);
                    infrared.setPixel(i,j,qRgb(red,green,blue));
                }
            }
            QPixmap pixmapinfrared = QPixmap::fromImage(infrared);
            ui->Main_Image->setPixmap(pixmapinfrared);
        }
    else if(Choice == 11 && ImageLoaded == 1){
        undo = image1;
        image1 = filter11disney(image1);;
        QImage disney(image1.width,image1.height,QImage::Format_RGB888);
        for (int i = 0; i < image1.width; ++i) {
            for(int j = 0; j < image1.height; ++j){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                disney.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapdisney = QPixmap::fromImage(disney);
        ui->Main_Image->setPixmap(pixmapdisney);
    }
        else if(Choice == 12 && ImageLoaded == 1){
            undo = image1;
            image1 = filter12contrast(image1);;
            QImage contrast(image1.width,image1.height,QImage::Format_RGB888);
            for (int i = 0; i < image1.width; ++i) {
                for(int j = 0; j < image1.height; ++j){
                    int red = image1(i,j,0);
                    int green = image1(i,j,1);
                    int blue = image1(i,j,2);
                    contrast.setPixel(i,j,qRgb(red,green,blue));
                }
            }
            QPixmap pixmapcontrast = QPixmap::fromImage(contrast);
            ui->Main_Image->setPixmap(pixmapcontrast);
        }
    else{
        QMessageBox Warning1;
        Warning1.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
        Warning1.setStyleSheet("QLabel{ color: white}");
        Warning1.setStyleSheet("QMessageBox{background-color:#55557F; color: white;}"
        "QPushButton {background-color:#5550B2 ;}");
        Warning1.setText("You Havent Selected an image!");
        Warning1.setIcon(QMessageBox::Critical);
        Warning1.exec();
    }
    QApplication::restoreOverrideCursor();
}

void MainWindow::on_ResetButton_clicked()
{
    image1 = backup;
    QImage backupImage(backup.width, backup.height, QImage::Format_RGB888);
    for(int i = 0; i < backup.width ; i++){
        for(int j = 0; j < backup.height ; j++){
            int red = backup(i,j,0);
            int green = backup(i,j,1);
            int blue = backup(i,j,2);
            backupImage.setPixel(i,j,qRgb(red,green,blue));
        }
    }
    QPixmap pixmapbackup = QPixmap::fromImage(backupImage);
    ui->Main_Image->setPixmap(pixmapbackup);
}



void MainWindow::mousePressEvent(QMouseEvent *event){
    origin = this->mapFromGlobal(event->globalPos());
    rubberband = new QRubberBand(QRubberBand::Rectangle, this);
    rubberband->setGeometry(QRect(origin,QSize()));
    rubberband->show();




}

void MainWindow::mouseMoveEvent(QMouseEvent *event){

    QPoint topcorner = ui->Main_Image->mapToGlobal(ui->Main_Image->rect().topLeft());
    QPoint bottomcorner = ui->Main_Image->mapToGlobal(ui->Main_Image->rect().bottomRight());
    QRect mainImageboundary(topcorner,bottomcorner);
    QPoint currentPos = event->pos();
    if(mainImageboundary.contains(currentPos) && (mainImageboundary.contains(origin))){
    rubberband->setGeometry(QRect(origin,event->pos()));
    }
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event){
    rubberband->hide();
}

void MainWindow::on_FuncApply_clicked()
{
    QApplication::setOverrideCursor(Qt::BusyCursor);
    QImage backupImage(backup.width, backup.height, QImage::Format_RGB888);
    for(int i = 0; i < backup.width ; i++){
        for(int j = 0; j < backup.height ; j++){
            int red = backup(i,j,0);
            int green = backup(i,j,1);
            int blue = backup(i,j,2);
            backupImage.setPixel(i,j,qRgb(red,green,blue));
        }
    }
    QPixmap pixmapbackup = QPixmap::fromImage(backupImage);
    ui->sec_Image->setPixmap(pixmapbackup);



    int Choice2 = ui->comboBox_2->currentIndex();

    Image image3;
    if(Choice2 == 0 && ImageLoaded == 1 ){
        // Open a file dialog for image selection
        QString imagePath2 = QFileDialog::getOpenFileName(nullptr, "Select Image", "", "Images (*.png *.jpg *.bmp)");

        // Check if the user canceled the dialog or no file was selected
        if (imagePath2.isEmpty()) {
            qDebug() << "No image selected";
            return;
        }
        image3.loadNewImage(imagePath2.toStdString());
        // Load the selected image
        QPixmap image4(imagePath2);

        // Check if the image was loaded successfully
        if (image4.isNull()) {
            qDebug() << "Failed to load image";
            return;
        }

        // Create a QLabel to display the image
        ui->sec_Image->setScaledContents(true);
        ui->sec_Image->setPixmap(image4);
        undo = image1;
        image1 = functionality1(image1,image3);
        QImage mergeImage(image1.width, image1.height, QImage::Format_RGB888);
        for(int i = 0; i < image1.width ; i++){
            for(int j = 0; j < image1.height ; j++){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                mergeImage.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapmerge = QPixmap::fromImage(mergeImage);
        ui->Main_Image->setPixmap(pixmapmerge);
    }
    else if(Choice2 == 1 && ImageLoaded == 1){
        undo = image1;
        image1 = functionality2(image1);
        QImage flipImage(image1.width, image1.height, QImage::Format_RGB888);
        for(int i = 0; i < image1.width ; i++){
            for(int j = 0; j < image1.height ; j++){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                flipImage.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapflip = QPixmap::fromImage(flipImage);
        ui->Main_Image->setPixmap(pixmapflip);
    }
    else if(Choice2 == 2 && ImageLoaded == 1){
        undo = image1;
        int totalRotation = (totalRotation + 90) % 360;
        image1 = functionality3rotate1(image1, totalRotation);
        QImage Rotate(image1.width, image1.height, QImage::Format_RGB888);
        for(int i = 0; i < image1.width ; i++){
            for(int j = 0; j < image1.height ; j++){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                Rotate.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmaprotate = QPixmap::fromImage(Rotate);
        ui->Main_Image->setPixmap(pixmaprotate);
    }
    else if(Choice2 == 3 && ImageLoaded == 1){
        undo = image1;
        value = ui->LDslider->value();
        std::cout<<value;
        image1 = functionalitylighten(image1);
        QImage lighten(image1.width, image1.height, QImage::Format_RGB888);
        for(int i = 0; i < image1.width ; i++){
            for(int j = 0; j < image1.height ; j++){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                lighten.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmaplighten = QPixmap::fromImage(lighten);
        ui->Main_Image->setPixmap(pixmaplighten);
    }
    else if(Choice2 == 4 && ImageLoaded == 1){
        value = ui->LDslider->value();
        undo = image1;
        image1 = functionalityldarken(image1);
        QImage darken(image1.width, image1.height, QImage::Format_RGB888);
        for(int i = 0; i < image1.width ; i++){
            for(int j = 0; j < image1.height ; j++){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                darken.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapdarken = QPixmap::fromImage(darken);
        ui->Main_Image->setPixmap(pixmapdarken);
    }
    else if(Choice2 == 5 && ImageLoaded == 1){
        // Check if rubberband selection is empty
        if (!rubberband) {
            QMessageBox Warning1;
            Warning1.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
            Warning1.setStyleSheet("QMessageBox {background-color:#55557F;}"
                                   "QPushButton {background-color:#5550B2 ; color: white;}");
            Warning1.setText("Warning! You haven't selected an area to crop. Please select an area by left-clicking and dragging.");
            Warning1.setStyleSheet("QPushButton { color:white ; background-color:#5550B2 ; }");
            Warning1.setIcon(QMessageBox::Critical);
            Warning1.exec();
            QApplication::restoreOverrideCursor();
            return;
        }

        // Check if the rubber band has a non-empty geometry
        QRect rubberBandGeometry = rubberband->geometry();
        if (rubberBandGeometry.isEmpty()) {
            QMessageBox Warning1;
            Warning1.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
            Warning1.setStyleSheet("QMessageBox{background-color:#55557F; color: white; }"
                                   "QPushButton {background-color:#5550B2 ; color: white; }");
            Warning1.setText("Warning! You haven't selected an area to crop. Please select an area by left-clicking and dragging.");
            Warning1.setIcon(QMessageBox::Critical);
            Warning1.exec();
            QApplication::restoreOverrideCursor();
            return;
        }

        // Proceed with cropping
        // Create a pixmap to capture the contents of the widget
        QPixmap widgetPixmap(this->size());
        QPainter widgetPainter(&widgetPixmap);
        this->render(&widgetPainter, QPoint(), QRegion(this->rect()));

        // Extract the portion of the pixmap within the rubber band selection
        QPixmap rubberBandPixmap = widgetPixmap.copy(rubberBandGeometry);

        // Convert the extracted pixmap to a QImage
        QImage image7 = rubberBandPixmap.toImage();
        QPixmap croppedimage = QPixmap::fromImage(image7);
        ui->Main_Image->setPixmap(croppedimage);
        Image Cropped_image(image7.width(),image7.height());
        for (int i = 0; i < image7.width(); ++i) {
            for(int j = 0; j < image7.height(); ++j){
                QColor color = image7.pixelColor(QPoint(i,j));
                int red = color.red();
                int green = color.green();
                int blue = color.blue();
                Cropped_image(i,j,0) = red;
                Cropped_image(i,j,1) = green;
                Cropped_image(i,j,2) = blue;
            }
        }
        image1 = Cropped_image;
    }
    else if(Choice2 == 6 && ImageLoaded == 1){
        undo = image1;
        image1 = functionality6edges(image1);
        QImage edges(image1.width, image1.height, QImage::Format_RGB888);
        for(int i = 0; i < image1.width ; i++){
            for(int j = 0; j < image1.height ; j++){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                edges.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapedges = QPixmap::fromImage(edges);
        ui->Main_Image->setPixmap(pixmapedges);
    }
    else if(Choice2 == 7 && ImageLoaded == 1){
        QMessageBox SliderValue2;
        SliderValue2.setIcon(QMessageBox::Information);
        SliderValue2.setWindowTitle("Degree of Skew");
        SliderValue2.setText("<div align='left'>Please insert your degree of Skew.</div>");
        SliderValue2.setStyleSheet("QMessageBox { background-color: #55557F;}"
        "QPushButton { background-color: #5550B2; color: white;}");
        QSlider *SkewDegree = new QSlider(Qt::Horizontal);
        SkewDegree->setRange(1, 89); // Set the range of the slider
        SkewDegree->setValue(45); // Set initial value
        SkewDegree->setMinimumWidth(150);
        SkewDegree->setStyleSheet("QSlider { Background-color:#5550B2; color:white;}");
        SliderValue2.layout()->addWidget(SkewDegree);
        float skew_Degree = SkewDegree->value();
        QObject::connect(SkewDegree, &QSlider::valueChanged, [&skew_Degree](int value2){
            skew_Degree = value2; // Update the kernel size
        });
        SliderValue2.exec();
        undo = image1;
        image1 = functionality6skew(image1, skew_Degree);
        QImage skew(image1.width, image1.height, QImage::Format_RGB888);
        for(int i = 0; i < image1.width ; i++){
            for(int j = 0; j < image1.height ; j++){
                int red = image1(i,j,0);
                int green = image1(i,j,1);
                int blue = image1(i,j,2);
                skew.setPixel(i,j,qRgb(red,green,blue));
            }
        }
        QPixmap pixmapskew = QPixmap::fromImage(skew);
        ui->Main_Image->setPixmap(pixmapskew);
    }
    else if(Choice2 == 8 && ImageLoaded == 1){
        // Create a custom dialog
        QDialog dialog;
        dialog.setWindowTitle("Resize");
        dialog.setStyleSheet("QDialog{background-color:#555072;}");
        dialog.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
        QLabel *label1 = new QLabel;
        label1->setText("Please Insert Your Desired New Boundaries");
        label1->setAlignment(Qt::AlignLeft);
        label1->setStyleSheet("QLabel{background-color:5550B2 ; color: white;}");
        QLineEdit lineEdit1;
        lineEdit1.setInputMask("9999");
        lineEdit1.setMaxLength(8);
        lineEdit1.setAlignment(Qt::AlignLeft);
        lineEdit1.setStyleSheet("QLabel{background-color:5550B2 ; color: white;}");
        QLineEdit lineEdit2;
        lineEdit2.setInputMask("9999");
        lineEdit2.setMaxLength(8);
        lineEdit2.setAlignment(Qt::AlignLeft);
        lineEdit2.setStyleSheet("QLabel{background-color:5550B2 ; color: white;}");
        QVBoxLayout layout(&dialog);
        layout.addWidget(&lineEdit1);
        layout.addWidget(&lineEdit2);
        layout.addWidget(label1);
        QDialogButtonBox buttonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
        layout.addWidget(&buttonBox);
        QObject::connect(&buttonBox, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
        QObject::connect(&buttonBox, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);

        // Show the dialog and execute it
        if (dialog.exec() == QDialog::Accepted) {
            QString inputText1 = lineEdit1.text();
            QString inputText2 = lineEdit2.text();
            bool ok;
            int value1 = inputText1.toInt(&ok);
            int value2 = inputText2.toInt(&ok);
            if (ok) {
                image1 = Functionality8resize(image1,value1,value2);
                QImage resize(image1.width, image1.height, QImage::Format_RGB888);
                for(int i = 0; i < image1.width ; i++){
                    for(int j = 0; j < image1.height ; j++){
                        int red = image1(i,j,0);
                        int green = image1(i,j,1);
                        int blue = image1(i,j,2);
                        resize.setPixel(i,j,qRgb(red,green,blue));
                    }
                }
                QPixmap pixmapresize = QPixmap::fromImage(resize);
                ui->Main_Image->setPixmap(pixmapresize);
            } else {
                QMessageBox::warning(nullptr, "Invalid Input", "Please enter a valid integer.");
            }
        }
    }
    else
    {
        QMessageBox Warning1;
        Warning1.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
        Warning1.setStyleSheet("QLabel{ color: white}");
        Warning1.setStyleSheet("QMessageBox{background-color:#55557F; color: white;}"
                               "QPushButton {background-color:#5550B2 ;}");
        Warning1.setText("You Havent Selected an image!");
        Warning1.setIcon(QMessageBox::Critical);
        Warning1.exec();
    }
    QApplication::restoreOverrideCursor();

}

void MainWindow::on_Savebtn_clicked()
{
    ImageSaved = 1;
    QMessageBox ExitSave;
    ExitSave.setWindowTitle("Unsaved Progress");
    ExitSave.setText("Please Insert Name For Your Image with extension type or without");
    QLineEdit lineEdit5;
    lineEdit5.setMaxLength(50);
    lineEdit5.setAlignment(Qt::AlignLeft);
    lineEdit5.setMinimumWidth(150);
    QVBoxLayout layout2(&ExitSave);
    layout2.addWidget(&lineEdit5);
    ExitSave.layout()->addWidget(&lineEdit5);
    ExitSave.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
    ExitSave.setStyleSheet("QMessageBox{background-color:#55557F; color: white;}"
                           "QPushButton {background-color:#5550B2 ; color: white;}");
    ExitSave.exec();
    QString Image_name1 = lineEdit5.text();
    std::string Image_Name = Image_name1.toStdString();
    if(Image_Name[-1] != 'P' || Image_Name[-4] != '.'){
        Image_Name = Image_Name + ".jpg";
    }
    image1.saveImage(Image_Name);
}


void MainWindow::on_ExitBtn_clicked()
{
    if(ImageLoaded == 1 && ImageSaved == 0){
        QMessageBox ExitQuestion;
        ExitQuestion.setWindowTitle("Unsaved Progress");
        ExitQuestion.setText("You haven't saved your progress. Are you sure you want to exit?");
        ExitQuestion.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        ExitQuestion.setDefaultButton(QMessageBox::No);
        ExitQuestion.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
        ExitQuestion.setStyleSheet("QMessageBox{background-color:#55557F; color: white;}"
                               "QPushButton {background-color:#5550B2 ; color: white;}");
        int result = ExitQuestion.exec();

        if (result == QMessageBox::Yes) {
            QApplication::quit();
        } else if (result == QMessageBox::No) {
            ImageSaved = 1;
            QMessageBox ExitSave;
            ExitSave.setWindowTitle("Unsaved Progress");
            ExitSave.setText("Please Insert Name For Your Image with or without extension type");
            QLineEdit lineEdit5;
            lineEdit5.setMaxLength(50);
            lineEdit5.setAlignment(Qt::AlignLeft);
            lineEdit5.setMinimumWidth(150);
            QVBoxLayout layout2(&ExitSave);
            layout2.addWidget(&lineEdit5);
            ExitSave.layout()->addWidget(&lineEdit5);
            ExitSave.setWindowIcon(QIcon(":/img1/Resoures/FlamePenguinIcon.png"));
            ExitSave.setStyleSheet("QMessageBox{background-color:#55557F; color: white;}"
            "QPushButton {background-color:#5550B2 ; color: white;}");
            ExitSave.exec();
            QString Image_name1 = lineEdit5.text();
            std::string Image_Name = Image_name1.toStdString();
            if(Image_Name[-4] != '.'){
                Image_Name = Image_Name + ".jpg";
                qDebug() << "Image_Name" <<  Image_Name;
            }
            image1.saveImage(Image_Name); // Convert string to const char* before passing to saveImage
        }
    }
    else{
            QApplication::quit();
    }
}


void MainWindow::on_UndoBtn_clicked()
{
    QImage UndoImage(undo.width, undo.height, QImage::Format_RGB888);
    for(int i = 0; i < undo.width ; i++){
        for(int j = 0; j < undo.height ; j++){
            int red = undo(i,j,0);
            int green = undo(i,j,1);
            int blue = undo(i,j,2);
            UndoImage.setPixel(i,j,qRgb(red,green,blue));
        }
    }
    QPixmap pixmapUndo = QPixmap::fromImage(UndoImage);
    ui->Main_Image->setPixmap(pixmapUndo);
    image1 = undo;
}
